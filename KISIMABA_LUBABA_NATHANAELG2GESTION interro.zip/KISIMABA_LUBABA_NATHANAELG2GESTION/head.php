<header>
	<h1>A.F.</h1>
	<p>
		<img src="smiler.png" alt="smiler" width="50" />
		Attribution des fonctions
		<img src="smiler.png" alt="smiler" width="50" />
	</p>
	<p>
		<a href="index.php">Agents</a> |
		<a href="fonctions.php">Fonctions</a> |
		<a href="taches.php">Tâches</a> 
	</p>
</header>