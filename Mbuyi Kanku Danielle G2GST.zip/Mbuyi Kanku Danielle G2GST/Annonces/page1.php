<?php
	
	echo '
		<strong>Annonce 1</strong>
		<p>
			Mark Zuck vient en RDC bientot<br/>
		</p>
		
	';
	

?>