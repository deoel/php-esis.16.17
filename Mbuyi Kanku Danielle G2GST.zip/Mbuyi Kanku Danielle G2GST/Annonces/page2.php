<?php
	
	echo '
		<strong>Annonce 2</strong>
		<p>
			Je suis sur Github<br/>
		</p>
		
	';
	

?>