﻿<?php
	echo '
			<strong>Annonce 3</strong>
			<p>
				Moïse sera le nouveau président<br/>
			</p>
		';
	
?>