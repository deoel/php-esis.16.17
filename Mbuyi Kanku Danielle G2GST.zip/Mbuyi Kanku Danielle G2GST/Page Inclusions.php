<?php
    echo '<h1>My Web Site</h1>';

    include 'page1.php';
    include_once 'page1.php';
    require 'page1.php';
    require_once 'page1.php';
?>