<?php

	echo '<h1>Karibu</h1>';
	//include
	

	require_once ('Annonces/page1.php');
	require_once ('Annonces/page2.php');
	require_once ('Annonces/page3.php');
	
	
	echo '<h3>Merci pour votre visite</h3>';
?>