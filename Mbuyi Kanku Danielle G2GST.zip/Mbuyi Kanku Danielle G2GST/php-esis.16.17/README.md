# php-esis.16.17
Cours de PHP/ESIS


Corriger le code source donné en classe par l’enseignant. <br />
Proposer des améliorations des scripts donnés par les différents étudiants. <br />
Optimiser les algorithmes des certains scripts.

