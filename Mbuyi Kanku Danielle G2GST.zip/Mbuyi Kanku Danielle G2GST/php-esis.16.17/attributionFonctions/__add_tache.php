<?php

	require_once('tache.class.php');
	require_once('tache.dao.php');
				
				
	//cette tache permet d'affecter un agent a une tache donnee
	if(isset($_POST['idagent']) and isset($_POST['description']) and !empty($_POST['datedebut']) and !empty($_POST['datefin'])) 
	{
		$descriptionTache = $_POST['description'];
		$datedebutTache = $_POST['datedebut'];
		$datefinFin = $_POST['datefin'];
		$idagent = $_POST['idagent'];

		$tache = new Tache(0, $descriptionTache,$datedebutTache,$datefinFin,$idagent);
		$tdao = new TacheDAO();
		
		if($tdao->AddTache($tache) == true)
		{
			//Redirection vers la page des taches
			header('Location: taches.php');
		}
		else
		{
			//redirection vers la page des taches
			header('Location: taches.php');
			echo 'Erreur : Systeme<br/>';
		}
		
	} 
	else 
	{
		echo 'Rassurrez-vous de bien avoir rempli tous les champs!';
	}

?>