<?php

	require_once('tache.class.php');
	require_once('tache.dao.php');
				
	//cette fonction est une version modifiee mais permet de modifier une tache pre - enregistree
	if(isset($_POST['id'],$_POST['description'],$_POST['datedebut'],$_POST['datefin'],$_POST['idagent']))
	{
		$t = new Tache($_POST['id'], $_POST['description'], $_POST['datedebut'], $_POST['datefin'], $_POST['idagent']);
    
	    $tache = new TacheDAO();
	    $tache->updateTache($t);
	    
	    header('Location: taches.php');
	}
	else
	{
		echo 'Certains champs sont vides ';
	}

?>