<!doctype>
<html>
	<head>
		<title>Attribution des fonctions</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<?php include_once('head.php'); ?>

		<div>
			
			<?php
			//ce fichier s'occupe de la suppression d'une tache selon l'id recu vie le parametre global gates
				require_once('tache.class.php');
				require_once('tache.dao.php');

				
				$tache = new TacheDAO();
				
				if(isset($_GET['id']))
				{
					$id = $_GET['id'];
					
					if($tache->delTache($id) === true)
					{
						echo "<p>Tache Supprimee Avec Succes</p>";
					}
					else
					{
						echo "<p>Tache Non Trouvee</p>";
					}
				}
			?>
		</div>
		
		<?php include_once('foot.php'); ?>
	</body>
</html>