<?php

	require_once('connexion.dao.php');
	
	class TacheDAO {
		private $bdd;
		function __construct() {
			$this->bdd = Connexion::getConnexion();
		}
		
		//Cette fonction lit et retourne toutes les taches de la bdd
		function getAllTache() {
			$req = $this->bdd->query('SELECT * FROM tache');
			$tabTache = array();
			while($data = $req->fetch()) {
				$a = new Tache($data['id'], $data['description'], $data['datedebut'], $data['datefin'], $data['idagent']);
				$tabTache[] = $a;
			}
			
			$req->closeCursor();
			
			return $tabTache;
		}
		//Cete fonction retourne une tache
		function delTache($id=null)
		{
			if($id != null)
			{
				$req = $this->bdd->query("DELETE FROM `tache` WHERE id='$id'");
				if($req == TRUE)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
		//Cette fonction retourne une tache correspondant a un id donne
		function getTache($id=null)
		{
			if($id != null)
			{
				$req = $this->bdd->query("SELECT * FROM tache WHERE id='$id'");
				$tabTache = array();
				while($data = $req->fetch()) {
					$a = new Tache($data['id'], $data['description'], $data['datedebut'], $data['datefin'], $data['idagent']);
					$tabTache[] = $a;
				}
			
			
				$req->closeCursor();
			
				return $tabTache[0];
			}
			else
			{
				return null;
			}
		}
		//Cette fonction retourne le nombre des taches a effectuer par l'agent
		function getTacheNbr($id=null)
		{
			if($id != null)
			{
				$req = $this->bdd->query("SELECT count(*) FROM tache WHERE idagent='$id'");
				$data = $req->fetchColumn();
				$req->closeCursor();
				return $data;
			}
			else
			{
				return 0;
			}
		}
		//la fonction recoit un objet tache en parametre et l'enregistre dans la base des donnees
		function AddTache($tache = null)
		{
			if($tache != null)
			{
				$description = $tache->getDescription();
				$dateDebut = $tache->getDatedebut();
				$dateFin = $tache->getDatefin();
				$idAgent = $tache->getIdagent();
				$req = $this->bdd->query("INSERT INTO tache (id, description, datedebut, datefin, idagent) VALUES (null, '$description', '$dateDebut', '$dateFin','$idAgent')");
				if($req == TRUE)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
		//cette fonction permet d'editer une tache donnee
		function editTache($tache = null)
		{
			if($tache != null)
			{
				$descriptionTache = $tache->getDescription();
				$dateDebutTache = $tache->getDatedebut();
				$dateFinTache = $tache->getDatefin();
				$idAgent = $tache->getIdAgent();
				$id = $tache->getId();
				$req = $this->bdd->query("UPDATE tache SET description='$descriptionTache', datedebut='$dateDebutTache', datefin='$dateFinTache', idAgent='$idAgent' WHERE id='$id'");
				if($req == TRUE)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}

		function updateTache($t)
		{
			if($tache != null)
			{
				$description = $tache->getDescription();
				$dateDebut = $tache->getDatedebut();
				$dateFin = $tache->getDatefin();
				$idAgent = $tache->getIdAgent();
				$id = $tache->getId();
				$req = $this->bdd->query("UPDATE tache SET description='$description', datedebut='$dateDebut', datefin='$dateFin', idAgent='$idAgent' WHERE id='$id'");
				if($req == TRUE)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				return false;
			}
		}
	}

?>