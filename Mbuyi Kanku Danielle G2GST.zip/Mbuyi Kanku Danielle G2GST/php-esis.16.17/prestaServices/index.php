<?php

	header('Location: vue/index.php');

?>