﻿<!doctype>
<html>
	<head>
		<title>PrestaService</title>
		<meta charset="utf-8" />
		<link rel="stylesheet" href="css/index.css" />
	</head>
	<body>
		<header>
			<h2>Welcome on PrestaService !</h2>
			<p>
				"Find the right person to get you a service"
			</p>
			<p>
				<a href="index.php">Home</a> |
				<a href="membre.php">Memberhood</a> |
				<a href="service.php">Services</a>
				<a href="../index.php">FR</a>
			</p>
		</header>
	</body>
</html>